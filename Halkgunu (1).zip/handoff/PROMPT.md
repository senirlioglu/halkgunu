# Claude Code prompt — halkgunu-web yenileme

Bu prompt'u Claude Code'a ver. Önce `handoff/` klasörünü repo'ya kopyala (ya da bu dosyaların içeriğini ek olarak yapıştır), sonra:

---

Sen halkgunu-web (Next.js 14 + TypeScript + Tailwind + Supabase) projesini mobil-first yenileyeceksin. **C · Bazaar** yönünü uyguluyorsun (sıcak, perakende DNA'lı, fiyat-merkezli).

## Yapma listesi (sırayla)

1. `handoff/DESIGN_SPEC.md` dosyasını **baştan sona oku.** Tüm değerler oradan gelir.
2. Mevcut kodu oku: `src/app/page.tsx`, `src/components/*`, `tailwind.config.ts`, `src/app/globals.css`, `src/app/layout.tsx`, `src/lib/types.ts`, `src/lib/api.ts`, `src/lib/format.ts`.
3. **Veri katmanına dokunma:** `src/lib/api.ts`, `src/lib/types.ts`, `src/lib/supabase.ts`, Supabase RPC'leri, RLS — hiçbiri değişmez.
4. Aşağıdaki PR'ları sırayla aç. Her PR ayrı commit, açıklayıcı mesaj.

### PR-1: Foundation

- `tailwind.config.ts` → `handoff/code/tailwind.config.ts` ile değiştir.
- `src/app/globals.css` → `handoff/code/globals.css` ile değiştir.
- `src/app/layout.tsx` → `handoff/code/layout.tsx` ile değiştir (font import + OG meta).
- `src/components/Logo.tsx` oluştur → `handoff/code/components/Logo.tsx`.
- `npm run build` çalıştır, hata yok ise commit.

### PR-2: Header + Tabs

- `src/components/Header.tsx` oluştur → handoff'tan kopyala. Sticky, skroll'da daralan.
- `src/components/EventTabs.tsx` → handoff ile değiştir. Yeni: `DateTabs` + `ModeToggle` (iki ayrı export).
- `src/app/page.tsx` içinde `<EventTabs ...>` çağrısını `<DateTabs />` + `<ModeToggle />` olarak böl. Header'ı en üste ekle, mevcut `<header>` bloğunu sil.
- Build + manuel test.

### PR-3: Liste view + arama + Geo CTA

- `src/components/ProductCard.tsx` → handoff ile değiştir (yeni placeholder, fiyat etiketi rozeti).
- `src/lib/search.ts` oluştur → `foldTr` / `matchTr`.
- `src/components/ListView.tsx` içinde mevcut filtre mantığını `matchTr` ile değiştir.
- `src/components/GeoCTA.tsx` oluştur → handoff'tan kopyala.
- `page.tsx` içinde `userPos` state'i ekle, `<GeoCTA onPermission={...}>` ile doldur, modal'a geçir.

### PR-4: Mağaza modalı

- `src/components/StoreModal.tsx` → handoff ile değiştir.
- Modal artık `urunAd`, `maxNormal`, `minIndirimli`, `userPos` proplarını alıyor — `page.tsx`'i güncelle (aktif ürünün full row'unu state'te tut, kod yerine).
- ESC tuşu ve body scroll lock dahil.

### PR-5: Routing + filtre sheet + lightbox + OG image

Tüm dosyalar `handoff/code/` altında hazır — birebir kopyala.

- `src/app/etkinlik/[id]/page.tsx` → `handoff/code/app/etkinlik/[id]/page.tsx` (server component, `generateMetadata` + `generateStaticParams`).
- `src/app/etkinlik/[id]/EventClient.tsx` → `handoff/code/app/etkinlik/[id]/EventClient.tsx` (mevcut `page.tsx` mantığını taşır, `Header` + `DateTabs` + `ModeToggle` + `GeoCTA` ile birleştirir).
- `src/app/page.tsx` → `handoff/code/app/page.tsx` ile değiştir (anasayfa artık ilk aktif etkinliğe `redirect()` eder; eski `?event=...` query param `/etkinlik/[id]`'ye yönlendirilir).
- `src/app/og/[id]/route.tsx` → `handoff/code/app/og/[id]/route.tsx` (next/og edge runtime, dinamik OG PNG).
- `src/components/FilterSheet.tsx` → `handoff/code/components/FilterSheet.tsx`. Aynı dosyadan `filterToQuery` / `queryToFilter` helper'ları + `DEFAULT_FILTER` export.
- `src/components/Lightbox.tsx` → `handoff/code/components/Lightbox.tsx`. **Dynamic import zorunlu**:
  ```ts
  const Lightbox = dynamic(() => import("@/components/Lightbox"), { ssr: false });
  ```
- `src/components/ListView.tsx` içinde `FilterSheet`'i bağla:
  - `useSearchParams` + `usePathname` + `router.replace` ile `FilterState` ↔ URL senkronu (`filterToQuery`/`queryToFilter`).
  - Sticky bar üstte: `[N ürün]` solda, `[⚙ Filtre <badge>]` ve `[↕ <sort label>]` sağda. İkisi de aynı sheet'i açar.
  - Filtre uygula sırası: arama → kategori → mağaza → minDiscount → sort.
- `src/components/PhotosView.tsx` içinde her foto kartını `<button onClick={() => setLightboxIdx(i)}>` yap. State: `const [lightboxIdx, setLightboxIdx] = useState<number | null>(null)`. Açıkken `<Lightbox photos={photos} startIndex={lightboxIdx} onClose={...} />`.

**Smoke test:**
- `/?event=test-2026-05-15` → `/etkinlik/test-2026-05-15` redirect.
- `/etkinlik/test-2026-05-15` direkt erişim çalışıyor.
- `/og/test-2026-05-15` → 1200×630 PNG.
- WhatsApp'a link yapıştırıp önizleme kontrol et.
- Filter sheet'te kategori seç + Uygula → URL'de `?cat=...` görün.
- Lightbox'ta ←/→ ve swipe çalışıyor.

## Genel kurallar

- Her PR'da `npm run build` ve `npm run lint` temiz olmalı.
- TypeScript strict — `any` kullanma, mevcut tipleri import et.
- Tailwind class adları doğrudan handoff dosyalarından kopyalandı; düzenlerken adlandırma şemasına uy.
- Türkçe metinleri **birebir** koru — UX yazımı bilinçli.
- Erişilebilirlik: `aria-label`, `role`, focus-visible halkaları zorunlu.
- Mobil 375px width'te test et; her ekran için tek scroll-container kuralı.

Bittiğinde özet ver: hangi dosyalar değişti, hangi PR'lar açıldı, kalan kısa to-do listesi.
