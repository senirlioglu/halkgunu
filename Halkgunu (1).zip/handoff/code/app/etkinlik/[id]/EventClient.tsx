// halkgunu-web/src/app/etkinlik/[id]/EventClient.tsx
// PR-5 — Server component'in client wrapper'ı. Mevcut page.tsx mantığını taşır,
// initial event id'yi server'dan props olarak alır.
"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  listEventPages, listEventPhotos, listEventProductSummary,
} from "@/lib/api";
import type {
  HalkgunuEvent, HalkgunuProductSummary,
} from "@/lib/types";
import type { ViewMode } from "@/lib/viewMode";
import { Header } from "@/components/Header";
import { DateTabs, ModeToggle } from "@/components/EventTabs";
import { GeoCTA } from "@/components/GeoCTA";
import { ListView } from "@/components/ListView";
import { PhotosView } from "@/components/PhotosView";
import { PosterView } from "@/components/PosterView";
import { StoreModal } from "@/components/StoreModal";
import { formatEventDate } from "@/lib/format";

interface Props {
  events: HalkgunuEvent[];
  initialEventId: string;
}

export default function EventClient({ events, initialEventId }: Props) {
  const router = useRouter();
  const [activeEventId, setActiveEventId] = useState<string>(initialEventId);
  const [mode, setMode] = useState<ViewMode>("liste");
  const [hasPoster, setHasPoster] = useState(false);
  const [hasPhotos, setHasPhotos] = useState(false);
  const [activeProduct, setActiveProduct] = useState<HalkgunuProductSummary | null>(null);
  const [userPos, setUserPos] = useState<{ lat: number; lng: number } | null>(null);

  // Active event değişince route'u güncelle (push değil replace — back stack temiz)
  useEffect(() => {
    if (activeEventId !== initialEventId) {
      router.replace(`/etkinlik/${activeEventId}`, { scroll: false });
    }
  }, [activeEventId, initialEventId, router]);

  // Poster/Foto varlığı
  useEffect(() => {
    let cancelled = false;
    listEventPages(activeEventId)
      .then(p => !cancelled && setHasPoster(p.length > 0))
      .catch(() => !cancelled && setHasPoster(false));
    listEventPhotos(activeEventId)
      .then(ph => !cancelled && setHasPhotos(ph.length > 0))
      .catch(() => !cancelled && setHasPhotos(false));
    return () => { cancelled = true; };
  }, [activeEventId]);

  const activeEvent = useMemo(
    () => events.find(e => e.event_id === activeEventId) ?? null,
    [events, activeEventId],
  );

  return (
    <main className="min-h-screen bg-paper-bg">
      <Header />

      <DateTabs
        events={events}
        activeEventId={activeEventId}
        onSelectEvent={(id) => { setActiveEventId(id); setMode("liste"); }}
      />
      <ModeToggle
        mode={mode}
        hasPoster={hasPoster}
        hasPhotos={hasPhotos}
        onChange={setMode}
      />

      <GeoCTA onPermission={(g) => {
        if (g) navigator.geolocation.getCurrentPosition(
          (pos) => setUserPos({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        );
      }} />

      {activeEvent && (
        <div className="px-4 pt-3">
          <h1 className="font-display text-lg font-extrabold text-ink-900 leading-tight">
            {activeEvent.event_name}
          </h1>
          <p className="text-xs text-ink-500 mt-0.5">{formatEventDate(activeEvent.event_date)}</p>
        </div>
      )}

      <div className="px-4 pb-12 pt-3">
        {mode === "afis" && hasPoster && activeEvent ? (
          <PosterView
            eventId={activeEvent.event_id}
            onProductClick={(kod) => setActiveProduct({ urun_kod: kod, urun_ad: null, max_normal: null, min_indirimli: null })}
          />
        ) : mode === "fotograflar" && hasPhotos && activeEvent ? (
          <PhotosView eventId={activeEvent.event_id} />
        ) : activeEvent ? (
          <ListView
            eventId={activeEvent.event_id}
            onProductClick={setActiveProduct}
          />
        ) : null}
      </div>

      {activeEvent && (
        <StoreModal
          eventId={activeEvent.event_id}
          urunKod={activeProduct?.urun_kod ?? null}
          urunAd={activeProduct?.urun_ad ?? undefined}
          maxNormal={activeProduct?.max_normal}
          minIndirimli={activeProduct?.min_indirimli}
          userPos={userPos}
          onClose={() => setActiveProduct(null)}
        />
      )}
    </main>
  );
}
