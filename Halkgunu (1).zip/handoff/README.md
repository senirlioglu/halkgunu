# Halk Günü — Claude Code Handoff (C · Bazaar Yönü)

Bu paket halkgunu.net'in mobil-first yenilenmesi için **C · Bazaar** yönünün
kod-uygulamaya-hazır spesifikasyonudur. Claude Code (veya başka bir asistan) bu
klasördeki dosyaları okuyarak mevcut `halkgunu-web` repo'suna düzenli, küçük
PR'lar halinde uygulayabilir.

## Klasör

| Dosya | Ne işe yarar |
|---|---|
| `DESIGN_SPEC.md` | Tüm tasarım sistemi: palet, tipografi, layout, bileşen state'leri, motion |
| `PROMPT.md` | Claude Code'a verilecek tek tık mega-prompt (kopyala-yapıştır) |
| `code/tailwind.config.ts` | Yeni token'lar — palet, font, shadow, animation |
| `code/globals.css` | Font import, base reset, utility class'lar (skeleton, sheet-handle, kraft-stripe) |
| `code/layout.tsx` | Bricolage + Inter font setup, OG meta |
| `code/lib/search.ts` | Türkçe-aware arama yardımcısı (foldTr / matchTr) |
| `code/components/Logo.tsx` | Inline SVG monogram (header + favicon) |
| `code/components/Header.tsx` | Sticky kompakt header (skroll'da daralır) |
| `code/components/EventTabs.tsx` | Tarih chip'leri + mod toggle (Liste/Afiş/Foto) |
| `code/components/GeoCTA.tsx` | Konum izni dismissable banner |
| `code/components/ProductCard.tsx` | Yeni kart — fiyat etiketi, indirim rozeti, placeholder |
| `code/components/StoreModal.tsx` | Bottom-sheet + segmented sıralama (Yakınlık/Fiyat/Stok) |
| `code/components/FilterSheet.tsx` | Filtre bottom-sheet — kategori/mağaza/min indirim/sıralama, URL senkronlu |
| `code/components/Lightbox.tsx` | Foto lightbox — swipe + ←/→, alt bantta caption + harita linki |
| `code/app/page.tsx` | Anasayfa — ilk aktif etkinliğe redirect, eski `?event=` query param uyumlu |
| `code/app/etkinlik/[id]/page.tsx` | Kanonik route, server component, `generateMetadata` + `generateStaticParams` |
| `code/app/etkinlik/[id]/EventClient.tsx` | Client wrapper — Header + tabs + view + modal'ı birleştirir |
| `code/app/og/[id]/route.tsx` | Dinamik 1200×630 OG image (next/og edge runtime) |

## Veri kontratı

**Hiç değişmez.** `src/lib/api.ts`, `src/lib/types.ts`, Supabase RPC'leri, RLS
policy'leri — hepsi olduğu gibi kalır. Bu sadece UI/UX yenilemesidir.

## Sıralama (önerilen PR'lar)

1. **PR-1** — Foundation: `tailwind.config.ts` + `globals.css` + `layout.tsx` + `Logo.tsx`
2. **PR-2** — Header + tabs: `Header.tsx`, `EventTabs.tsx` (DateTabs + ModeToggle)
3. **PR-3** — Liste view yenileme: `ProductCard.tsx` + `lib/search.ts` + `GeoCTA.tsx`
4. **PR-4** — Modal: `StoreModal.tsx` (bottom-sheet, segmented sıralama)
5. **PR-5** — Routing (`/etkinlik/[id]` + redirect) · Filter bottom-sheet · Lightbox · Dinamik OG image

Her PR bağımsız deploy edilebilir. PR-5 öncesi canlıya çıkış mümkündür.
