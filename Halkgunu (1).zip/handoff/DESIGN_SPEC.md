# Halk Günü — C · Bazaar Tasarım Spesifikasyonu

> **Yön:** "Halk Pazarı" — sıcak, samimi, perakende DNA'sı yüksek.
> **Hedef:** halkgunu.net mobil-first yenileme. Mevcut kod tabanı: Next.js 14 App Router + TypeScript + Tailwind + Supabase.
> **İlke:** Mevcut veri kontratı (Supabase tabloları, RPC'ler, type'lar) **dokunulmaz**. Sadece UI katmanı (`src/app/page.tsx` + `src/components/*` + `tailwind.config.ts` + `src/app/globals.css`) değişir.

---

## 1. Marka Kimliği

### 1.1 Konsept
"Halk Günü" adı bir pazar/tezgâh ritüelini çağrıştırıyor. Mevcut tasarım jenerik bir SaaS gradient'ı kullanıyor (mor #667eea → #764ba2). Yeni yön bu jenerikliği bırakıp **Türk perakende geleneğine** yaklaşıyor: kâğıt zemin (kraft pazar poşeti rengi), domates kırmızısı (indirim/etiket), hardal sarısı (vurgu/dikkat), siyaha çalan koyu kahve metin.

### 1.2 Logo
İki üst üste şeritten oluşan bir **pazar tezgâhı tentesi** monogramı + "halkgünü" wordmark (Bricolage Grotesque, ExtraBold, letter-spacing -0.04em, küçük "g" ile minuscule).

- **Tente** (32×32 viewBox 0 0 40 40):
  - Üst trapez: `M4 13 L20 5 L36 13 L36 17 L4 17 Z` — kırmızı `#c1272d`
  - 3 dikey şerit: x=6/17/28, y=17, w=6, h=18 — sarı/kırmızı/sarı (`#eab308` / `#c1272d` / `#eab308`)
  - Alt taban: `x=6 y=33 w=28 h=3` — kırmızı `#c1272d`
- Tek renk varyantı (mono): tüm path'ler `#1c1410` (ink-900) — favicon ve baskı için.
- Wordmark: `halkgünü` — küçük harfle, `letter-spacing: -0.04em`, ana renk `#c1272d`. Header'da tente + wordmark yan yana.

### 1.3 Tipografi
| Rol | Aile | Ağırlık | Kullanım |
|---|---|---|---|
| Display | **Bricolage Grotesque** | 600/700/800 | Wordmark, başlıklar, fiyat (büyük), tarih sayıları |
| Body | **Inter** | 400/500/600/700 | Tüm gövde metni, fiyat etiketi (küçük), formlar |
| Mono | `ui-monospace` (system) | 500/700 | Ürün kodu, mağaza kodu, stok |

Google Fonts URL (Next `app/layout.tsx` içine):
```
https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=Inter:wght@400;500;600;700;800&display=swap
```

### 1.4 Renk Sistemi (Tailwind tokenları)
```
brand:
  primary:   #c1272d  // domates / indirim / aksiyon
  primaryD:  #a01e23  // hover, active
  primaryS:  #fff1f0  // soft bg, chip
accent:
  primary:   #eab308  // hardal / dikkat / vurgu
  primaryD:  #ca8a04
  primaryS:  #fef3c7
ink:
  900: #1c1410   // metin
  700: #3a2a20   // ikincil metin
  500: #78635a   // muted
  300: #d6c8bd   // border-strong
paper:
  bg:      #fef9ed   // sayfa zemini (kâğıt)
  surface: #ffffff   // kart, modal
  border:  #ecdfd0   // standart border
success:   #15803d / soft #dcfce7   // foto/yeşil sekme
danger:    #c1272d (= primary)      // indirim — primary ile aynı; kasıtlı
```
**Kullanım kuralı:**
- Primary kırmızı sadece aksiyon, indirim ve birincil CTA'da. Header bg'sinde değil.
- Accent sarı sadece "Afiş" sekmesi, vurgu rozetleri ve dekoratif şeritlerde.
- Paper-bg sayfa zeminidir; surface kart/modal. İkisi arasında her zaman `border` ile sınır var.

### 1.5 Şekil Sistemi
- `radius.card`: **18px** (yumuşak, el yapımı hissi)
- `radius.pill`: 999px
- `radius.sheet`: **28px** (modal üst köşeleri)
- Border default: `1px solid paper.border` (çoğu yerde) veya **kesikli** (`2px dashed paper.border`) — kâğıt etiket hissi için header altı, banner çevresi.
- Gölge:
  - `shadow.card`: `0 2px 0 rgba(28,20,16,0.08), 0 6px 14px rgba(28,20,16,0.08)` (alt-sol kâğıt gölgesi)
  - `shadow.sheet`: `0 -8px 24px rgba(28,20,16,0.12)`

### 1.6 Hareket
- Geçişler 150-220ms `cubic-bezier(0.2, 0.8, 0.2, 1)` (yumuşak ease-out).
- Kart hover: 1px sınır rengi `paper.border` → `brand.primary` + 2px translate-y(-1px). Mobilde aktif state aynı.
- Modal/Sheet açılışı: 280ms slide-up + fade.
- Bbox tıklama feedback: 120ms scale(0.97) + accent flash.

---

## 2. Bilgi Mimarisi

### 2.1 Hiyerarşi (mobil-first)
```
[Sticky kompakt header]      ← scroll'da küçülür (h: 56 → 48)
[Tarih sekmeleri]            ← yatay scroll, snap
[Mod toggle: Liste / Afiş / Foto]   ← 3-segmentli
─── Liste modu ───
  [Arama kutusu]
  [Kategori chip'leri (yatay scroll)]
  [Geo CTA banner — opt-in, dismiss'lenebilir]
  [Filtre + Sıralama satırı (sticky)]
  [Ürün gridi — 2 sütun mobile, 3 sütun ≥640, 4 sütun ≥768, 5 sütun ≥1024]
─── Afiş modu ───
  [Tıklanabilir bbox overlay'li poster]
  [Sayfa thumbnail'ları (>1 sayfa varsa)]
─── Foto modu ───
  [Foto gridi 2 sütun]
  [Karta tıklayınca lightbox (full-screen, swipe nav)]
```

### 2.2 Routing
- **Kanonik:** `/etkinlik/[event_id]` — Next dynamic route. `generateMetadata` ile etkinlik bazlı OG image (`/og/[event_id]`).
- **Alias:** `/?event=...` query param destekli (eski linkler). `useEffect` içinde `router.replace('/etkinlik/${id}')`.
- **Anasayfa `/`:** Aktif etkinlik(ler)den ilkine `redirect()` (sıralama: sort_order asc, event_date desc).
- 404 / yok: "Aktif Halk Günü etkinliği yok" boş state ekranı.

---

## 3. Ekran-Ekran Spesifikasyon

### 3.1 Header (sticky kompakt)
**Geniş hâli (sayfa üstünde):**
- BG: `paper.bg` (kâğıt). Alt sınır: `2px dashed paper.border`.
- Soldan: 36px tente logosu + `halkgünü` wordmark (Bricolage 20/800, kırmızı).
- Wordmark altı: `İYİBULUR · 3 ETKİNLİK` (Inter 10/700, ink.500, letter-spacing 0.08em, uppercase).
- Sağda: 36×36 yuvarlak konum butonu (📍 ikonu, `surface` bg, border).

**Kompakt hâli (scroll y > 80px):**
- Yükseklik 48px, `position: sticky top-0`, `backdrop-filter: blur(8px)`, BG `rgba(254,249,237,0.92)`.
- Logo 24px + `halkgünü` 14/700. Aktif tarih chip'i sağda.

**Davranış:**
```ts
const [scrolled, setScrolled] = useState(false);
useEffect(() => {
  const onScroll = () => setScrolled(window.scrollY > 80);
  window.addEventListener('scroll', onScroll, { passive: true });
  return () => window.removeEventListener('scroll', onScroll);
}, []);
```

### 3.2 Tarih sekmeleri
Yatay scroll, `scroll-snap-type: x mandatory`. Her sekme:
- `flex` row, `gap: 10px`. Solda: 2 satırlı gün kutusu — `MAY` (10/700, opacity 0.7) + `15` (Bricolage 22/800, -0.03em). Sağda: etkinlik adı (Inter 13/600).
- Aktif: `bg: brand.primary` → `accent.primary` lineer gradient (135°), beyaz metin, `shadow.card`.
- Pasif: `bg: surface`, ink.900 metin, `border: 1px solid paper.border`.
- Border-radius **12px** (pill değil — bilet hissi).

### 3.3 Mod toggle
3 eşit segment, gap 6px, padding 10px 12px. Aktif segment dolgulu:
- Liste aktif → `brand.primary`
- Afiş aktif → `accent.primary`
- Foto aktif → `success`
Pasif segmentler: `surface`, `border`. Sadece "Afiş" `hasPoster` ise, "Foto" `hasPhotos` ise görünür.

### 3.4 Arama kutusu
- `surface` bg, `border: 1px solid paper.border`, `radius.card`.
- Sol içerde 🔍 (ink.500, 14px). Padding `10px 12px 10px 34px`.
- Focus: `border: 2px solid brand.primary`, `outline: none`.
- Placeholder: "Ürün adı veya kodu ara…" (ink.500).
- Türkçe arama: query ve `urun_ad` ikisi de `toLocaleLowerCase("tr").normalize("NFD").replace(/[\u0300-\u036f]/g,"")` ile fold edilir; "sut" → "süt"ü bulur.

### 3.5 Kategori chip'leri
Yatay scroll, gap 6px. Pasif: `surface` + `border`, ink.700. Aktif: `ink.900` (siyah) + beyaz metin. Padding 6/12, radius pill. Kategori listesi backend'den distinct `urun_ad` ile değil; `halkgunu_products.kategori` kolonu YOKsa ilk faz için `urun_kod` prefix'i ile (örn. `AYG-` → `Gıda`) static map.

### 3.6 Geo CTA banner
- `accent.primaryS` (sarı soft) bg, `2px dashed accent.primary` border, `radius.card`.
- 32px yuvarlak ikon (📍, accent bg, beyaz emoji) + 2 satırlı metin + `İzin ver` butonu (accent.primary bg, beyaz, pill, 11/700).
- Dismiss: `localStorage.getItem('hg_geo_dismissed') === '1'` → render etme. Sağ üstte küçük × butonu set'ler.
- Reddedildiyse modal'da "Konum kapalı, fiyata göre sıralı" notu görünür.

### 3.7 Filtre + sıralama satırı (sticky, liste üstünde)
- `position: sticky`, `top: header-compact-height`, `bg: paper.bg`, `border-bottom: 1px solid paper.border`.
- Sol: `[N ürün]` (ink.500). Sağ: 2 chip — `⚙ Filtre` (sayaç badge: aktif filtre sayısı) ve `↕ En çok indirim` (sıralama).
- Tıklanınca **bottom-sheet** açılır:
  - Kategori (multi chip), Mağaza (multi, search'lü liste), Min indirim slider (% 0-70), Sıralama (radio: En çok indirim / En düşük fiyat / Yakınlık / Stok). Alt sticky `Uygula (N ürün)` butonu — primary kırmızı.

### 3.8 Ürün kartı
- Grid: `grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5`. Mobilde daima 2 sütun.
- Kart: `surface`, `border: 1px solid paper.border`, `radius.card`, `shadow.card`, padding 0.
- **Resim alanı** (aspect-square, `paper.bg`):
  - Çapraz şerit pattern: `repeating-linear-gradient(135deg, paper.bg 0 8px, surface 8px 16px)`.
  - Üstüne: kategoriye göre ikon (kâğıt baskı hissi, ink.700, 32px, opacity 0.7) + altında ürün kodunun ilk segmenti küçük bir rozette (örn `AYG`, mono, 10px).
  - Resim varsa: `object-contain p-2` ile yerleştir.
  - **İndirim rozeti** (sağ üst): yamuk fiyat etiketi formu (clip-path), `brand.primary` bg, beyaz metin, `−%32` (Bricolage 12/800).
  - **Sol alt rozet**: `12 mağaza` (mono, surface bg, ink.700, 10/700, padding 2/6, radius 4).
- **İçerik alanı** (padding 10px):
  - Ürün kodu satırı (mono, 10/500, ink.500).
  - Ürün adı (Bricolage 13/600, ink.900, line-clamp-2, min-h 32px).
  - Fiyat satırı: indirimli (Bricolage 16/800, brand.primary, -0.02em) + üstü çizili normal (Inter 11/500, ink.500).

### 3.9 Mağaza modal (bottom-sheet)
- Backdrop: `rgba(0,0,0,0.4)`, `backdrop-filter: blur(2px)`.
- Sheet: `surface`, `border-radius 28px 28px 0 0`, `max-height: 85vh`, alta yapışık.
- **Drag handle** üstte (4×36, ink.300).
- **Ürün başlık satırı**: 64×64 placeholder + ürün kodu/adı/fiyat + sağda × kapat. Altta `1px solid border`.
- **Sıralama segmented**: `[Yakınlık | Fiyat | Stok]` — `paper.bg` track'inde, aktif segment `surface` + shadow. Altında "5 mağazada mevcut · konumuna göre sıralı" notu.
- **Mağaza kartı listesi**: her kart için indeks-bazlı renk paleti (success/primary/accent/danger sırasıyla). Sol border 4px o renk, bg `linear-gradient(135deg, color/10%, color/5%)`. İçerik:
  - Üst satır: mağaza adı + km rozeti (`0.8 km`, surface bg, color border).
  - Adres (10/500, ink.500, line-clamp-2).
  - `M01 · stok 24` (mono, 10/500, ink.500).
  - Sağda fiyat (Bricolage 15/800, brand.primary) + üstü çizili normal.
  - Alt satır: `📍 Yol tarifi →` link (brand.primary, 11/600).

### 3.10 Afiş modu
- Sayfa thumbnail'ları (>1 ise): yatay scroll, 80×96 kart, aktif olan `2px solid brand.primary + shadow`.
- Ana poster: `surface` çerçeve, `radius.card`, `border 1px paper.border`, full width.
- Bbox'lar:
  - `urun_kodu` varsa: `border: 2px solid accent.primary`, `bg: accent.primary/12`, sağ üst köşe küçük 📍 ikon (12px). Tıklama → bottom-sheet (modal yerine — kullanıcı afişe geri dönmek istediğinde aynı sayfada kalır).
  - `urun_kodu` yoksa: `border: 2px dashed ink.300`, opacity 0.4, disabled.
- Üstte 11/500 ink.500 ipucu metni: "Bir ürüne dokunarak satıldığı mağazaları gör".

### 3.11 Foto modu + Lightbox
- Grid: 2 sütun mobil, 3 sütun ≥640. Kart: `surface`, `border`, `radius.card`. Resim aspect-4/3, `object-cover`. Alt blok: mağaza adı (11/700, ink.900), adres (10/500, ink.500), caption (11/500, ink.700).
- **Lightbox**: tam ekran `bg: rgba(0,0,0,0.92)`. Üstte `1/6` sayacı + × kapat. Ortada resim (aspect-4/5, max 92%w, radius 16). Sol/sağ ‹ › butonları (36×36, glass). Alt bantta `bg: rgba(0,0,0,0.6)` + mağaza adı/adres/caption + `📍 Haritada göster →` chip (success bg, beyaz).
- Klavye: ←/→ navigate, Esc kapat. Touch: yatay swipe (`pointerdown/move/up`, threshold 50px).

### 3.12 Boş / Loading / Hata state'leri
- **Loading (liste):** 6 adet skeleton kart — gri pattern + 2 satır gri çizgi. Pulse animasyonu.
- **Loading (modal):** drag handle + 3 satır mağaza skeleton.
- **Boş (etkinlik yok):** kâğıt zemin merkez, tente logosu 64px (gri), "Şu an aktif Halk Günü yok" (Bricolage 20/700) + "Sosyal medyamızdan duyurularımızı takip et" (Inter 13/500).
- **Boş (ürün yok):** "Bu etkinlik için ürün listesi henüz hazır değil" — animasyonlu kâğıt etiket SVG.
- **Boş (arama sonuç yok):** "[arama] için sonuç yok" + "Filtreleri temizle" butonu.
- **Hata:** "Bir şey ters gitti" + retry butonu + technical details collapse'lı.

### 3.13 OG Image (1200×630, `/og/[event_id]`)
- BG: `linear-gradient(135deg, brand.primary 0%, accent.primary 140%)`.
- Sol üst: 84px tente logo + `Halk Günü` (Bricolage 64/800) + `halkgunu.net` (Inter 22/500).
- Sol alt: `15 Mayıs · Cuma` (Bricolage 84/800) + tek satır açıklama.
- Sağ: 3 dekoratif fiyat etiketi rozeti, hafif rotate, beyaz bg, indirim yüzdesi + ürün adı.
- Next.js: `app/og/[event_id]/route.tsx` — `next/og` `ImageResponse` ile dinamik üretim.

---

## 4. Erişilebilirlik (A11y)
- Tüm interaktif öğelere `aria-label`. `<button title>` yetersiz.
- Modal `role="dialog" aria-modal="true"` + focus trap (`focus-trap-react`) + Esc handler.
- Kategori chip'leri `role="tab"`, container `role="tablist"`.
- Renk kontrastı: kırmızı/sarı bg üstüne beyaz metin AA pass; soft bg + primary text de AA pass — devtools ile test.
- Bbox `<button>` `aria-label="${urun_kodu} — ${urun_aciklamasi}"`.
- Keyboard nav: Tab tüm önemli öğelere ulaşır, focus ring `2px solid brand.primary, offset 2px`.

---

## 5. Performans
- Fontlar: `next/font/google` ile `Bricolage_Grotesque` ve `Inter` self-host. `display: 'swap'`. `subsets: ['latin', 'latin-ext']` (Türkçe için zorunlu).
- Resim placeholder her zaman ilk render — gerçek resim arkadan yükler. CLS sıfır olmalı (aspect-square sabit).
- Lightbox lazy: `dynamic(() => import('@/components/Lightbox'), { ssr: false })`.
- Kategori map'i ve filtre state'i URL query param'a yazılır (`?cat=Gıda&sort=indirim`) — paylaşılabilir, Back butonu çalışır.
- Skeleton'lar 200ms gecikmeyle göster (yanıp sönme önlenir): hızlı bağlantıda hiç görünmez.

---

## 6. PWA (P2 — sonraki sprint)
- `manifest.json` (theme-color: `#c1272d`, bg-color: `#fef9ed`, name: "Halk Günü", short_name: "Halk Günü", icons: `/icon-192.png`, `/icon-512.png`).
- Service worker: Workbox `next-pwa` plugin. Etkinlik listesi 1h cache, ürün listesi 5dk, foto/poster image stale-while-revalidate.
- "Ana ekrana ekle" iOS Safari hint (sadece Safari + standalone değilse).
- Web Push opt-in: "Yaklaşan Halk Günü için bildirim al" — aktif etkinliğin tarihinden 24h önce push.

---

## 7. Yapılacaklar Listesi (P0 — bu sprint, sırayla)

1. **Token & font katmanı**: `tailwind.config.ts` yenile + `app/layout.tsx`'e font yükle + `app/globals.css` güncelle.
2. **Logo + favicon**: SVG component + public/favicon.ico + apple-touch-icon.
3. **Header (kompakt + sticky scroll-shrink)**: yeni `components/Header.tsx`.
4. **EventTabs**: tarih + mod toggle ayrı bileşenlere böl (`DateTabs`, `ModeToggle`).
5. **ProductCard**: yeniden yaz — yeni placeholder, yamuk indirim rozeti, mağaza sayısı rozeti.
6. **Filter & Sort sticky bar + bottom-sheet**: yeni `components/FilterSheet.tsx`. URL query param ile state.
7. **GeoCTA**: yeni `components/GeoCTA.tsx`. `localStorage` dismiss.
8. **StoreModal**: bottom-sheet'e dönüştür + sıralama segmented + km rozeti + Yol tarifi link.
9. **PhotosView + Lightbox**: yeni `components/Lightbox.tsx`, dynamic import.
10. **PosterView**: bbox stillerini güncelle, modal yerine bottom-sheet.
11. **Empty/Loading/Error state'leri**: her view için skeleton + boş ekran component'leri.
12. **Routing**: `/etkinlik/[event_id]/page.tsx` oluştur, `/page.tsx`'i redirect'e dönüştür, query param fallback.
13. **OG image**: `app/og/[event_id]/route.tsx` ile `next/og`.
14. **A11y geçişi**: focus trap, aria-label, role'ler, kontrast denetimi.
15. **Türkçe arama foldlama**: `lib/search.ts` helper + ListView'da kullan.

---

## 8. Yapılmayacaklar / Sınırlar
- **Supabase şemasına dokunma** — `arahalk.md`'deki Ara admin tarafı sözleşmesi sabit.
- **Tüm copy Türkçe**, mevcut tone of voice korunur (samimi, kısa, emoji yok — opsiyonel ☕📍 gibi anlamlı işaretler hariç).
- **Dark mode P2 olsun**, bu sprintte kapsam dışı (token'lar `dark:` prefix'i ile hazırlanır ama implement edilmez).
- **i18n yok** — sadece TR.

---

## 9. Kabul Kriterleri (testler)
- [ ] Mobilde (375×667) tüm ekranlarda yatay scroll yok.
- [ ] Lighthouse mobile: Performance ≥ 90, A11y ≥ 95, Best Practices ≥ 95.
- [ ] CLS = 0 (resim placeholder + aspect-ratio).
- [ ] `/etkinlik/test-2026-05-15` direkt linki çalışır.
- [ ] Mağaza modal'ında "Yakınlık" sıralaması geo izin yoksa disabled + tooltip.
- [ ] Foto lightbox keyboard ile gezilir.
- [ ] WhatsApp'a `/etkinlik/...` linki yapıştırılınca doğru OG image görünür.
- [ ] Tüm interaktif öğelerde focus-visible ring görünür.
- [ ] Türkçe arama: "sut" → "süt" eşleşir.

---

## 10. Sonraki sprint adayları (P1/P2)
Detay için `RECS.md`'ye bak. Özetle: PWA + push, favori ürün, fiyat değişim göstergesi, karşılaştırma görünümü, harita önizleme.
